from fastapi import HTTPException
from fastapi.responses import JSONResponse

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from data import username, password  # Make sure to replace with your actual email and password

fixed_subject = "Verification code"


# Function to send email
async def send_email1(email,verification_code):
    fixed_message = f"Your 5 digit Verification code: {verification_code}"
    smtp_server = "smtp.gmail.com"
    smtp_port = 587  # TLS port for Gmail
    msg = MIMEMultipart()
    msg["From"] = username  # Replace with your email
    msg["To"] = email
    msg["Subject"] = fixed_subject
    msg.attach(MIMEText(fixed_message, "plain"))
    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # Upgrade connection to TLS
            server.login(username, password)  # Login with your email credentials
            server.sendmail(username, email, msg.as_string())  # Send email
            return JSONResponse(
                status_code=200, content={"details": f"Email sent successfully to {email}"}
            )

    except Exception as e:
        print(f"Error sending email: {e}")
        raise HTTPException(status_code=500, detail="Email not sent successfully")


