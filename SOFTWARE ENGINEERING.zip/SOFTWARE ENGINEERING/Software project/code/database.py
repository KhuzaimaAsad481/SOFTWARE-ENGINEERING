import uvicorn
from pydantic import BaseModel
from pathlib import Path
from fastapi import FastAPI, Form, Depends, HTTPException, Request, BackgroundTasks,File,UploadFile
from sqlalchemy.orm import Session, sessionmaker, declarative_base
from sqlalchemy import create_engine, Integer, String, Column
import random
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse,RedirectResponse
from fastapi.staticfiles import StaticFiles
import httpx
from send_mail import send_email1
from PIL import Image
import io
import torch
from model import predict_image
from starlette.middleware.sessions import SessionMiddleware
from authlib.integrations.starlette_client import OAuth, OAuthError
get_email={}
get_email_forget={}
# Function to generate verification code
def v_code():
    return random.randint(10000, 99999)


verification_code = v_code()
vcode1=""
# Database connection settings
SQL_ALCHEMY_DATABASE_URL = "mysql+pymysql://root:@localhost/Fake_image_detection"
engine = create_engine(SQL_ALCHEMY_DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


oauth = OAuth()
oauth.register(
    name="google",
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_id="610538991757-6i1rno8vnhac5d2bcl1a85om8b4h81a9.apps.googleusercontent.com",
    client_secret="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",
    client_kwargs={
        'scope': 'openid profile email',
    },
)


# FastAPI app initialization
app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key="Fake_image_detection")
# Path for templates (HTML files)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")


# SQLAlchemy Database Models
class Register(Base):
    __tablename__ = "register"
    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100), index=True)
    last_name = Column(String(100), index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String(100), index=True)

class C_With_Google(Base):
    __tablename__ = "c_with_google"
    id = Column(Integer, primary_key=True, autoincrement=True,index=True)
    email = Column(String, unique=True, nullable=False,index=True)
    username = Column(String, nullable=False,index=True)

class C_With_Github(Base):
    __tablename__ = "c_with_github"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    name = Column(String, nullable=False, index=True)
    user_id = Column(Integer, nullable=False, index=True)






# Create all tables in the database
Base.metadata.create_all(bind=engine)


# Pydantic models for user registration and login
class UserCreate(BaseModel):
    email: str
    password: str
    first_name: str
    last_name: str

    @classmethod
    def as_form(
            cls,
            first_name: str = Form(...),
            last_name: str = Form(...),
            email: str = Form(...),
            password: str = Form(...),
    ) -> "UserCreate":
        return cls(first_name=first_name, last_name=last_name, email=email, password=password)


class LoginUser(BaseModel):
    email: str
    password: str

    @classmethod
    def as_form(cls, email: str = Form(...), password: str = Form(...)) -> "LoginUser":
        return cls(email=email, password=password)


# Database helper functions
def create_user(db: Session,email:str,first_name:str,last_name:str,password:str ):
    db_user = Register(email=email, first_name=first_name, last_name=last_name,
                       password=password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def create_user_with_google(db:Session,email:str,user_name:str):
    db_user1=C_With_Google(email=email,username=user_name)
    db.add(db_user1)
    db.commit()
    db.refresh(db_user1)
    return db_user1

def create_user_with_github(db:Session,name:str,user_id:int):
    db_user2=C_With_Github(name=name,user_id=user_id)
    db.add(db_user2)
    db.commit()
    db.refresh(db_user2)
    return db_user2


def get_user_by_email_google(db: Session, email: str):
    return db.query(C_With_Google).filter(C_With_Google.email == email).first()

def get_user_by_github(db:Session,user_id):
    return db.query(C_With_Github).filter(C_With_Github.user_id==user_id).first()


def get_user_by_email(db: Session, email: str):
    return db.query(Register).filter(Register.email == email).first()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/", response_class=HTMLResponse)
def dispay_home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})


# Routes for user registration and login
@app.get("/register", response_class=HTMLResponse)
def get_form_data(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@app.get("/verification", response_class=HTMLResponse)
def get_form_data(request: Request):
    return templates.TemplateResponse("verification.html", {"request": request})


@app.post("/verification", response_class=HTMLResponse)
def verify_code(request: Request,backgroundtask:BackgroundTasks, vcode1: str = Form(...),db: Session = Depends(get_db)):
    email=get_email.get("email")
    first_name=get_email.get("f_name")
    last_name = get_email.get("l_name")
    password = get_email.get("password")
    newpassword=get_email_forget.get("newpassword")
    password1=get_email_forget.get("password")
    email2=get_email_forget.get("email")
    print(email)
    print("mail",email,"fname",first_name,"lname",last_name,"password",password)
    print(f"Verification code received: {vcode1}")
    vcode2=int(vcode1)
    verification_code2=int(verification_code)
    if newpassword:
        if verification_code2 == vcode2:
            user = db.query(Register).filter(Register.email == email2).first()  # Fetch the user instance
            if user:
                user.password = newpassword
                db.commit()
                db.refresh(user)
                message2 = True
            else:
                message2 = False
        return templates.TemplateResponse("verification.html", {"request": request, "message2": message2})
    if verification_code2==vcode2:
        print("account created")
        message=True
        create_user(db=db, email=email,first_name=first_name,last_name=last_name,password=password)
    return templates.TemplateResponse("verification.html", {"request": request,"message":message})




@app.post("/register", response_model=UserCreate, status_code=201)
def reg_user(request: Request, backgroundtask: BackgroundTasks, user: UserCreate = Depends(UserCreate.as_form),
             db: Session = Depends(get_db)):
    get_email["email"] = user.email
    get_email["f_name"]=user.first_name
    get_email["l_name"] = user.last_name
    get_email["password"] = user.password
    print(user)
    existing_user = get_user_by_email(db, email=user.email)
    if existing_user:
        message3=True
        return templates.TemplateResponse("register.html", {"request": request,"message3":message3})
    backgroundtask.add_task(send_email1, user.email, verification_code)
    return RedirectResponse(url="/verification", status_code=303)


@app.get("/login", response_class=HTMLResponse)
def get_form_data1(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})


@app.post("/login")
def login_user(request: Request, user: LoginUser = Depends(LoginUser.as_form), db: Session = Depends(get_db)):
    print(user.email)
    mail = get_user_by_email(db, email=user.email)
    print(mail)
    if not mail or mail.password != user.password:
        raise HTTPException(status_code=400, detail="Invalid email or password")
    return templates.TemplateResponse("mainpage.html", {"request": request,
                                                        "message": "User logged in successfully!"})  # issue aa raha ha


@app.get("/forget",response_class=HTMLResponse)
def gen_response(request: Request):
    return templates.TemplateResponse("forget.html", {"request": request})


@app.post("/forget",response_class=HTMLResponse)
def gen_response(request: Request,backgroundtask:BackgroundTasks,email:str=Form(...),password:str=Form(...),newpassword:str=Form(...),):
    print(email,password,newpassword)
    if password!=newpassword:
        message1=True
        return templates.TemplateResponse("forget.html", {"request": request,"message1":message1})
    backgroundtask.add_task(send_email1, email, verification_code)
    get_email_forget["email"] = email
    get_email_forget["newpassword"] = newpassword
    return RedirectResponse(url="/verification", status_code=303)


UPLOAD_DIR = Path(r"static/model_images")  # Create a folder named 'uploaded_images' in your project directory
UPLOAD_DIR.mkdir(exist_ok=True)  # Ensure the directory exists

@app.post("/upload")
async def upload_image(request: Request, image: UploadFile = File(...)):
    try:
        # Validate uploaded file type
        if not image.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="Invalid image format")

        # Read the uploaded image file
        contents = await image.read()
        image_data = Image.open(io.BytesIO(contents))
        print(image_data)
        # Define the path to save the image
        file_path = UPLOAD_DIR / image.filename
        with open(file_path, "wb") as f:
            f.write(contents)

        # Store the file path in a variable
        image_path = str(file_path.resolve())  # Absolute path of the saved image
        print(f"Image URL: {image_path}")  # Debugging: Print the image URL
        print(image_path)
        model_path = r'C:\Users\hp\Desktop\SE\model\ViT\ViT.pth'
        vit_model = torch.load(model_path, map_location=torch.device('cpu'))
        vit_model.eval()  # Set the model to evaluation mode

        try:
            prediction = predict_image(vit_model, image_path)
            print(f"The image is classified as: {prediction}")
        except Exception as e:
            print(f"An error occurred: {e}")
        # Return the result with the stored URL
        return templates.TemplateResponse("mainpage.html", {
            "request": request,
            "image_url": image_path,"prediction":prediction  # Pass the image URL to the template
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/logout")
def logout(request: Request):
    # Remove the user from the session or reset the session
    request.session.clear()
    return RedirectResponse(url="/login")


@app.get("/google-register")
async def google_reg(request:Request):
    redirect_uri = request.url_for("auth")
    return await oauth.google.authorize_redirect(request, redirect_uri)

@app.get("/auth")
async def auth(request: Request,db:Session=Depends(get_db)):
    try:
        token = await oauth.google.authorize_access_token(request)
        userinfo = token.get('userinfo')
        if userinfo:
            email=userinfo.get('email')
            name=userinfo.get('name')
            print(f"User Email: {userinfo.get('email')}")
            print(f"User Name: {userinfo.get('name')}")
            get_data=get_user_by_email_google(db,email)
            print(get_data)
            if get_data:
                message4=True
                return templates.TemplateResponse("mainpage.html", {"request": request,
                                                                    "message": "User  logged in successfully!","message4":message4})
            #     return templates.TemplateResponse("register.html", context={"request": request, "message4": message4})

            db_user1=create_user_with_google(db,email,name)
            print("user store in db",db_user1)
            message5 = True
            # print("User Info:", userinfo)  # Debugging purpose
    except OAuthError as e:
        return templates.TemplateResponse(
            "error.html", context={"request": request, "error": e.error}
        )
    return templates.TemplateResponse("register.html", context={"request": request, "message5": message5})


github_client_id = "Ov23liSug7XaBXlmASIX"
github_client_secret = "5e853923b7dc8b0ac31243cb52e4e3ca290787ad"

@app.get("/github-login")
async def githublogin():
    return RedirectResponse(
        f"https://github.com/login/oauth/authorize?client_id={github_client_id}",
        status_code=302,
    )
@app.get("/github-code")
async def github_code(code: str, request: Request, db: Session = Depends(get_db)):
    print(f"Received code: {code}")
    params = {
        "client_id": github_client_id,
        "client_secret": github_client_secret,
        "code": code,
    }
    try:
        headers = {"Accept": "application/json"}
        async with httpx.AsyncClient() as client:
            # Exchange code for access token
            token_response = await client.post(
                url="https://github.com/login/oauth/access_token",
                params=params,
                headers=headers,
            )
            token_json = token_response.json()
            access_token = token_json.get("access_token")
            print(f"Access token: {access_token}")

            if not access_token:
                raise ValueError("Failed to retrieve access token.")

            # Fetch user details from GitHub API
            headers.update({"Authorization": f"Bearer {access_token}"})
            user_response = await client.get("https://api.github.com/user", headers=headers)
            user_data = user_response.json()
            print(f"GitHub user data: {user_data}")

            name = user_data.get("name")
            github_id = user_data.get("id")

            if not name or not github_id:
                raise ValueError("Incomplete user data from GitHub.")

            # Check if the user exists in the database
            existing_user = get_user_by_github(db, github_id)
            if existing_user:
                print(f"User exists: {existing_user}")
                message6 = True
                return templates.TemplateResponse(
                    "mainpage.html", {"request": request, "message6": message6}
                )

            # Create new user if not found
            new_user = create_user_with_github(db, name, github_id)
            print(f"New user created: {new_user}")
            message7 = True
            return templates.TemplateResponse(
                "register.html", {"request": request, "message7": message7}
            )

    except Exception as e:
        print(f"Error occurred: {e}")
        return templates.TemplateResponse(
            "error.html", {"request": request, "error": str(e)}
        )



if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8002)   # run on 8002 port because at google clousd console and github developer 8002 set as callback_uri
